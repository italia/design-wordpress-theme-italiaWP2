<div class="form-group">
    <label class="sr-only"><?php echo __('Search for Topics','italiawp2'); ?></label>
        <button type="submit" class="ico-sufix">
            <svg class="icon"><use xlink:href="<?php echo esc_url( get_template_directory_uri() ); ?>/static/img/ponmetroca.svg#ca-search"></use></svg>
        </button>
</div>
