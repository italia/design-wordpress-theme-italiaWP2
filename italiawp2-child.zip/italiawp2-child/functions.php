<?php

add_action('wp_enqueue_scripts', 'carica_stili_parent');
function carica_stili_parent() {
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');
}

add_action( 'wp_head', 'carica_head_custom' );
function carica_head_custom() { ?>
    <!-- Custom <head> content -->
<?php }
